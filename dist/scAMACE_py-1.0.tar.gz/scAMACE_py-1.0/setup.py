from setuptools import setup

setup(
    name='scAMACE_py',
    version='1.0',
    # packages=[''],
    url='',
    # license='',
    install_requires=['numpy','torch','scipy'],
    author='Zexuan SUN, Jiaxuan WANGWU',
    author_email='wwjiaxuan@link.cuhk.edu.hk',
    description='scAMACE(integrative Analysis of single-cell Methylation, chromatin ACcessibility, and gene Expression) python implementation, a model-based approach to the joint analysis of single-cell data on chromatin accessibility, gene expression and methylation.'
)
